import logging
from fastapi import FastAPI, Request

#from solver import Solver
#from solver_orderbook import Solver
#from solver_uniswap import Solver
from solver_hybrid import Solver
from datatypes import SolveRequest

app = FastAPI()

logging.basicConfig(level=logging.INFO)


@app.get("/")
async def read_root():
    return {"message": "MOO"}


@app.get("/health", status_code=200)
def health() -> bool:
    return True


@app.post("/notify", response_model=bool)
async def notify(request: Request) -> bool:
    print(f"Notify request {await request.json()}")
    return True


@app.post("/solve")
async def solve(request: SolveRequest):
    solver = Solver()
    results = solver.solve(request)
    if len(results["solutions"][0]["prices"]) == 0:
        return {"solutions": []}
    return results


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
