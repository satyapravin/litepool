import json
import torch
import random
import warnings
from typing import List, Tuple
from math import sqrt
from collections import defaultdict
from dataclasses import dataclass
from typing import Union, List, Dict
from math import sqrt
from decimal import Decimal

import numpy as np
from numpy import inf
import pandas as pd


def construct_jit_order(sell_token, buy_token, start_amount, output_amount):
    fee_percentage = 0.003
    fee = 0.3#int(sell_amount * fee_percentage)

    jit_order = {
        "kind": "jit",
        "executedAmount": str(output_amount),
        "fee": str(fee),
        "order": {
            "sellToken": sell_token,
            "buyToken": buy_token,
            "receiver": '0x0000000000000000000000000000000000000000',
            "sellAmount": str(output_amount),
            "buyAmount": str(start_amount),
            "validTo": 0,
            "appData": "0x0000000000000000000000000000000000000000000000000000000000000000",
            "kind": "sell",
            "sellTokenBalance": "erc20",
            "buyTokenBalance": "erc20",
            "signingScheme": "eip712",
            "signature": "0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        }
    }
    
    return jit_order

def construct_custom_interactions(executed_cycles, interaction_id=0):
    interactions = []
    #for cycle_index, cycle in enumerate(executed_cycles):
    start_amount = executed_cycles[0]['startAmount']
    steps = executed_cycles[0]['steps']
    outputs = executed_cycles[1]  # This is now a separate list

    for i, (step, output) in enumerate(zip(steps, outputs)):
        pool = step['uniswapV2']['pool']
        input_token = step['uniswapV2']['token_in']
        output_token = step['uniswapV2']['token_out']

        # For the first step, use the start_amount as input_amount
        # For subsequent steps, use the previous step's output as input_amount
        input_amount = start_amount if i == 0 else outputs[i-1]
        output_amount = output

        interaction = {
            "kind": "custom",
            "id": interaction_id+i,  # Unique ID for each interaction
            "inputToken": input_token,
            "outputToken": output_token,
            "inputAmount": str(input_amount),
            "outputAmount": str(output_amount),
            "internalize": True
        }

        interactions.append(interaction)
    
    return interactions


def construct_liquidity_interactions(sell_amounts, buy_amounts, input_token, output_token, interaction_id=0):
    interactions = []

    for i, (output_amount, input_amount) in enumerate(zip(sell_amounts, buy_amounts)):

        interaction = {
            "kind": "liquidity",
            "id": interaction_id+i,  # Unique ID for each interaction
            "inputToken": input_token,
            "outputToken": output_token,
            "inputAmount": str(input_amount),
            "outputAmount": str(output_amount),
            "internalize": True
        }

        interactions.append(interaction)
    
    return interactions



