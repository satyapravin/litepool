import json
import torch
import random
import warnings
from typing import List, Tuple
from math import sqrt
from collections import defaultdict
from dataclasses import dataclass
from typing import Union, List, Dict
from math import sqrt
from decimal import Decimal

import numpy as np
from numpy import inf
import pandas as pd


@dataclass
class ProcessedOrederbook:
    address:str
    selltoken: str
    buytoken: str
    kind: str
    partiallyFillable: bool
    sellReference: float
    buyReference: float
    sellETH: float
    buyETH: float
    limit_price: float
    ETH_limit_price: float
    surplus: float
    fee: float
    
@dataclass
class ProcessedAMM:
    address: str
    selltoken: str
    buytoken: str
    kind: str
    partiallyFillable: bool
    sellReference: float
    buyReference: float
    sellETH: float
    buyETH: float
    limit_price: float
    ETH_limit_price: float
    surplus: float
    fee: float

@dataclass
class SoulutionComponents:
    seller_orderbooks: List
    source_id: str
    target_id: str
    inputs_per_order: List
    eth_inputs_per_order: List
    eth_returns_per_order: List
    adjusted_returns_per_order: List
    executed_cycles: List
    original_tokens_rate: float
    our_tokens_rate: List
    original_token_clearing_price: str
    our_token_clearing_price: str
    sellETHprice: str
    buyETHprice: str
    surplusses: List
    
@dataclass
class OrderShadow():
    reserves: torch.Tensor
    ai: torch.IntTensor  # size = [2]
    dtype: torch.dtype

    def __init__(
        self, reserves: List[float], ai: List[int], dtype=torch.float64, fee=1
    ):
        self.reserves = torch.tensor(reserves, dtype=dtype)
        self.fee = fee
        self.ai = torch.tensor(ai, dtype=torch.int32)
        self.dtype = dtype

    def Ai(self) -> torch.IntTensor:
        return self.ai
    
@dataclass
class PyOrderShadow():
    def __init__(
        self, reserves: List[float], ai: List[int], dtype=np.float64, fee=1
    ):
        self.reserves = np.array(reserves, dtype=dtype)
        self.fee = fee
        self.ai = np.array(ai)
        self.dtype = dtype

    def Ai(self):
        return self.ai

class TokensRegistry:
    tokens: Dict[str, int]
    next_id: int

    def __init__(self):
        self.tokens = {}
        self.next_id = 0

    def get_token_id(self, token: str) -> int:
        token = token.lower()
        if not token in self.tokens:
            self.tokens[token] = self.next_id
            self.next_id += 1
        return self.tokens[token]

    def get_token_addr(self, id: int) -> str:
        for addr, _id in self.tokens.items():
            if id == _id:
                return addr
        return None

    def iter_tokens_sorted(self):
        tokens = [{"addr": key, "id": value} for key, value in self.tokens.items()]
        tokens.sort(key=lambda x: x["id"])

        for entry in tokens:
            yield entry["addr"]

    def __len__(self):
        return len(self.tokens)



