import os
import json
from datetime import datetime
import requests
import numpy as np
from decimal import Decimal, getcontext
from typing import List, Dict, Tuple
import torch
from datatypes import SolveRequest
from preprocessing import ProcessedOrederbook, ProcessedAMM, SoulutionComponents, TokensRegistry
from postprocessing import construct_jit_order, construct_custom_interactions, construct_liquidity_interactions
from pathfinder import create_exchange_dict, compute_WETH_max_exchange_and_flow, find_paths, orderbook_filter_cycles, \
    create_transport_solution
from orderbook_utils import limit_sell_surplus, limit_buy_surplus, detect_rich_orderbook, get_indicies, \
    get_WETH_amounts, get_pool_WETH_amounts, simulate_cycle_outputs
from price_extractor import torch_find_arb

from pydantic import BaseModel, Field
getcontext().prec = 36

def filter_pools(pools, reference_price):
    filtered_pools = []
    for pool in pools:
        if pool['t0'] in reference_price and pool['t1'] in reference_price:
            filtered_pools.append(pool)
    return filtered_pools

class Solver:
    def __init__(self):
        self.reference_price = {}
        self.reference_tokens = []
        self.tokens_registry = TokensRegistry()
        self.all_tokens_registry = TokensRegistry()

        # with open("./data/orderbook_pools_20240906_052653.json", "r") as f:
        #     pools = json.loads(f.read())
        # self.all_pools = pools

    def preprocess_data(self, orderbook: SolveRequest, verbose=True) -> Tuple[List, List, List, Dict, Dict]:

        # Fetch pool data
        pools_url = 'http://18.223.66.155:8020/extract-v2-pools'
        pools_headers = {'Content-Type': 'application/json'}
        # original code
        for token in orderbook.tokens:
            self.reference_price[token.address] = [int(token.price), float(token.price) / 10 ** (18)]
            if int(token.price) == 10 ** 18:
                self.reference_tokens.append(token.address)

        orders_dict = {order.uid: order for order in orderbook.orders}

        addresses = np.load('data/updated_pool_addresses.npy').tolist()

        # actual_orderbook_pools = filter_pools(self.all_pools, self.reference_price)
        # print('Total actual orderbook pools:', len(actual_orderbook_pools))
        # addresses = [pool['pool_addr'] for pool in actual_orderbook_pools]
        # np.save('./data/updated_pool_adresses.npy', np.array(addresses))
        
        response = requests.post(pools_url, headers=pools_headers, json=addresses[:])
        orderbook_pools = response.json()

        # Process orders
        processed_orders = []
        all_orders = []
        partiallyFillable = 0
        NoNpartiallyFillable = 0

        for order in orderbook.orders:
            realsellamount = np.float64(str(order.sellAmount))
            realbuyamount = np.float64(str(order.buyAmount))
            sellETHprice = int(self.reference_price[order.sellToken][0])
            buyETHprice = int(self.reference_price[order.buyToken][0])

            sellETHamount, buyETHamount = get_WETH_amounts(order, self.reference_tokens,
                                                           sellETHprice, buyETHprice,
                                                           realsellamount, realbuyamount)

            if order.partiallyFillable:
                partiallyFillable += 1
            else:
                NoNpartiallyFillable += 1

            limit_price = np.float64(realsellamount / realbuyamount)
            ETH_limit_price = np.float64(sellETHamount / buyETHamount)

            if order.kind == 'buy':
                surplus = limit_buy_surplus(realsellamount, sellETHprice, realbuyamount, buyETHprice, limit_price)
            elif order.kind == 'sell':
                surplus = limit_sell_surplus(realsellamount, sellETHprice, realbuyamount, buyETHprice, limit_price)

            if surplus == 0:
                selected_orderbook = ProcessedOrederbook(
                    order.uid,
                    order.sellToken,
                    order.buyToken,
                    order.kind,
                    order.partiallyFillable,
                    realsellamount,
                    realbuyamount,
                    sellETHamount,
                    buyETHamount,
                    limit_price,
                    ETH_limit_price,
                    surplus,
                    1
                )

                all_orders.append(selected_orderbook)

                if sellETHamount / buyETHamount >= 0.99:
                    processed_orders.append(selected_orderbook)

        # Process pools
        selected_pools = []
        for order in orderbook_pools:
            #print(order)
            realsellamount = int(order['r0'])
            realbuyamount = int(order['r1'])
            try:
                sellETHprice = int(self.reference_price[order['t0']][0])
                buyETHprice = int(self.reference_price[order['t1']][0])
    
                sellETHamount, buyETHamount = get_pool_WETH_amounts(order, self.reference_tokens,
                                                               sellETHprice, buyETHprice,
                                                               realsellamount, realbuyamount,
                                                               sellkey='t0', buykey='t1')
                limit_price = np.float64(realsellamount / realbuyamount)
                ETH_limit_price = np.float64(sellETHamount / buyETHamount)
    
                if sellETHamount > 0.1:
                    selected_pools.append(ProcessedAMM(
                        order['pool_addr'],
                        order['t0'],
                        order['t1'],
                        None,
                        True,
                        realsellamount,
                        realbuyamount,
                        sellETHamount,
                        buyETHamount,
                        limit_price,
                        ETH_limit_price,
                        None,
                        1
                    ))
            except:
                continue

        # Optimize selected pools
        cfmms_potential = {}
        optimized_selected_pools = []
        for j, cfmm_data in enumerate(selected_pools):
            ETHprices = [self.reference_price[cfmm_data.selltoken][0], self.reference_price[cfmm_data.buytoken][0]]
            reserves = torch.tensor([cfmm_data.sellETH, cfmm_data.buyETH])
            v = torch.nn.parameter.Parameter(torch.tensor([1, 1], dtype=torch.float64), requires_grad=True)
            v_optimizer = torch.optim.Adadelta([v], lr=0.01)
            best_loss = 0
            best_v = v

            for _ in range(5):
                v_optimizer.zero_grad()
                Delta, Lambda = torch_find_arb(v, reserves, 0.997)
                objective_loss = (Lambda - Delta).sum()
                loss = -objective_loss
                loss.backward()
                v_optimizer.step()
                if objective_loss.item() > best_loss:
                    best_loss = objective_loss.item()
                    best_v = v
            try:
                Delta, Lambda = torch_find_arb(best_v, reserves, cfmm_data.fee)
                Delta, Lambda = Lambda.detach().numpy() - Delta.detach().numpy()
                token_changes = {}
                for i, x in enumerate([Delta, Lambda]):
                    if x < 0:
                        token_changes['input_index'] = i
                        token_changes['value_in'] = x
                        token_changes['token_in'] = [cfmm_data.selltoken, cfmm_data.buytoken][i]
                        token_changes['reserves_x'] = abs((token_changes['value_in'] / ETHprices[i]) * (10 ** (18 * 2)))
                    elif x > 0:
                        token_changes['value_out'] = x
                        token_changes['token_out'] = [cfmm_data.selltoken, cfmm_data.buytoken][i]
                        token_changes['reserves_y'] = abs((token_changes['value_out'] / ETHprices[i]) * (10 ** (18 * 2)))
                token_changes['surplus'] = objective_loss.item()
                cfmms_potential[j] = token_changes
    
                optimized_selected_pools.append(ProcessedAMM(
                    cfmm_data.address,
                    token_changes['token_out'],
                    token_changes['token_in'],
                    'uniswapV2',
                    True,
                    int(token_changes['reserves_y']),
                    int(token_changes['reserves_x']),
                    abs(token_changes['value_out']),
                    abs(token_changes['value_in']),
                    None,
                    abs(token_changes['value_out']) / abs(token_changes['value_in']),
                    None,
                    0.997,
                ))
            except:
                continue
        if verbose:
            print('PartiallyFillable:', partiallyFillable)
            print('NoNpartiallyFillable:', NoNpartiallyFillable)
            print('Selected orders:', len(all_orders))
            print('Top selected orders:', len(processed_orders))
            print('Selected pools:', len(selected_pools))
            print('Optimized selected pools:', len(optimized_selected_pools))
            print('\n-------------------------------------------------------------------------\n')

        return all_orders, processed_orders, optimized_selected_pools, orders_dict, cfmms_potential

    def solve(self, request: SolveRequest, verbose=True):
        # Initialize variables
        orderbook = request
        pools = None
        v2_prices = []

        # Preprocess data
        all_orders, processed_orders, optimized_selected_pools, orders_dict, cfmms_potential = self.preprocess_data(
            orderbook)

        # Sort and prepare data
        sorted_by_WETH = sorted(all_orders, key=lambda item: item.ETH_limit_price, reverse=True)
        processed_sorted_by_Amount = sorted(processed_orders, key=lambda item: item.sellETH, reverse=True)

        pair_to_indices, _ = get_indicies(sorted_by_WETH, pair_key=True)
        top_pair_to_indices, _ = get_indicies(processed_sorted_by_Amount, pair_key=True)

        # Initialize solution
        unique_pairs = optimized_selected_pools.copy()
        resulted_solution = {
            "solutions": [
                {
                    "id": 0,
                    "prices": {},
                    "trades": [],
                    "pre_interactions": [],
                    "interactions": [],
                    "post_interactions": [],
                    "scores": [],
                    "gas": ""
                }
            ]
        }

        # Main solving loop
        number_of_orders = len(pair_to_indices)
        swaps_to_drop = []
        used_tokens = []
        trades = []
        total_WETH = 0
        total_surplus = 0
        Path_len = 6
        uniform_prices = []
        remaining_amounts = {idx: order.buyETH for idx, order in enumerate(unique_pairs)}
        prev_remaining_amounts = remaining_amounts.copy()
        tokens_rate = {}
        interactions = []
        solver_iterations = 0

        temporal_solutions = []
        for i in range(number_of_orders):
            solving_orderbook = list(pair_to_indices.items())[i]
            source_id = solving_orderbook[0][0]
            target_id = solving_orderbook[0][1]
        
            exchange_dict = create_exchange_dict(unique_pairs.copy(), swaps_to_drop)
            sellETHprice = (self.reference_price[source_id][0])
            buyETHprice = (self.reference_price[target_id][0])
        
            cycles = []
            for N in range(Path_len):
                find_paths(exchange_dict, source_id, target_id, [], cycles, N)
        
            cycle_stat, cycle_used_orders, valid_cycle_stat, all_orders_cycles, remaining_amounts = orderbook_filter_cycles(
                cycles, unique_pairs, compute_WETH_max_exchange_and_flow, prev_remaining_amounts, 1.0, True)
        
            inputs_per_order = []
            eth_inputs_per_order = []
            sellers_ids = []
            sellingETH = 0
            seller_orderbooks = []
        
            if len(valid_cycle_stat) > 0:
                single_cycle = valid_cycle_stat[0]
                single_cycle_amount = single_cycle['max_eth_flow']
        
                for order, index in solving_orderbook[1]['orders']:
                    if 1 / order.ETH_limit_price < single_cycle['final_rate']:
                        eth_inputs_per_order.append(order.sellETH)
                        sellers_ids.append(order.address)
                        inputs_per_order.append(int(order.sellReference))
                        sellingETH += order.sellETH
                        seller_orderbooks.append(order)
        
                        if sellingETH >= single_cycle_amount:
                            break
        
                if sellingETH <= single_cycle_amount:
                    eth_returns_per_order = [single_cycle_amount]
                    user_price = {0: single_cycle['final_rate']}
                else:
                    j = 0
                    buyingETH = 0
                    eth_returns_per_order = []
                    user_price = {}
                    for cycle in valid_cycle_stat:
                        eth_returns_per_order.append(cycle['max_eth_flow'])
                        user_price[j] = cycle['final_rate']
                        buyingETH += cycle['max_eth_flow']
                        j += 1
        
                        if buyingETH >= sellingETH:
                            break
        
                if len(eth_inputs_per_order) > 0 and len(eth_returns_per_order) > 0:
                    #try:
                    TransportSolution = create_transport_solution(eth_inputs_per_order, eth_returns_per_order,
                                                                  user_price)
                    executed_cycles = []
                    if TransportSolution.sum() > 0:
                        returns_list = []
                        for c, cycle_amountIn in enumerate(TransportSolution):
                            sum_cycle_amountIn = sum(cycle_amountIn)
                            if sum_cycle_amountIn != 0.0:
                                returns_weight = [x / sum_cycle_amountIn for x in cycle_amountIn]
                                real_sum_cycle_amountIn = int((sum_cycle_amountIn / sellETHprice) * (10 ** (18 * 2)))
                                simulated_responce, simulation_data = simulate_cycle_outputs(
                                    valid_cycle_stat[c]['cycle'], unique_pairs, source_id, real_sum_cycle_amountIn, False)
                                simulation_json = simulated_responce.json()
                                amountOut = simulation_json['amountOut']
                                amountOutHops = simulation_json['amountOutHops']
        
                                returns_per_order = [int(x * np.float64(amountOut)) for x in returns_weight]
                                returns_list.append(returns_per_order)
                                executed_cycles.append([simulation_data, amountOutHops])
        
                        returns_per_order = np.sum(np.array(returns_list), axis=0)
                        eth_returns_per_order = [x * (buyETHprice / 10 ** (18 * 2)) for x in returns_per_order]
        
                        #collect the resulted uniform rates
                        original_tokens_rate = buyETHprice / sellETHprice
                        our_tokens_rate = []
                        for sellamount, buyamount in zip(inputs_per_order, returns_per_order):
                            if buyamount == 0:
                                our_tokens_rate.append(Decimal('Infinity'))
                            else:
                                our_tokens_rate.append(int(sellamount) / int(buyamount))
        
                        
                        #fixing the resulted tokens rates
                        if len(set(our_tokens_rate)) == 1:
                            our_tokens_rate = our_tokens_rate[0]
                            adjusted_returns_per_order = returns_per_order
                        else:
                            our_tokens_rate = round(max(our_tokens_rate), 36)  #or min here
                            adjusted_returns_per_order = [int((int(sellamount) / our_tokens_rate)) for sellamount in inputs_per_order]
        
                        #compute the clearing price for token
                        price_multiplyer = our_tokens_rate/original_tokens_rate 
                        our_token_clearing_price = int(sellETHprice*price_multiplyer)
        
                        adjusted_tokens_rate = []
                        surpluses = []
                        for order, sellETHamount, buyETHamount, sellamount, buyamount in zip(seller_orderbooks,
                                                                                             eth_inputs_per_order,
                                                                                             eth_returns_per_order,
                                                                                             inputs_per_order,
                                                                                             adjusted_returns_per_order):
                            if order.kind == 'sell':
                                surplus = limit_sell_surplus(sellamount, int(sellETHprice), int(buyamount),
                                                             int(buyETHprice), np.float64(order.limit_price))
                            else:
                                surplus = limit_buy_surplus(sellamount, int(sellETHprice), int(buyamount),
                                                            int(buyETHprice), np.float64(order.limit_price))
                            surpluses.append(int(surplus) / (10 ** (18 * 2)))
                            adjusted_tokens_rate.append(int(sellamount) / int(buyamount)) # we changed buy amounts. P.s adjusted_tokens_rate must be equal to our_tokens_rate
                            total_WETH += sellETHamount
        
                        #if sum(surpluses)>0:
                        temporal_solutions.append(SoulutionComponents(seller_orderbooks= seller_orderbooks,
                                                    source_id = str(source_id),
                                                    target_id = str(target_id),
                                                    inputs_per_order = inputs_per_order,
                                                    eth_inputs_per_order =  eth_inputs_per_order,
                                                    eth_returns_per_order = eth_returns_per_order,
                                                    adjusted_returns_per_order= adjusted_returns_per_order,
                                                    executed_cycles= executed_cycles,
                                                    original_tokens_rate = original_tokens_rate,
                                                    our_tokens_rate = adjusted_tokens_rate,
                                                    original_token_clearing_price = sellETHprice,
                                                    our_token_clearing_price = our_token_clearing_price,
                                                    sellETHprice = sellETHprice,
                                                    buyETHprice = buyETHprice, 
                                                    surplusses= surpluses))
                    #except:
                        #continue
        
        solutions_sorted_by_surplus = sorted(temporal_solutions, key=lambda item: sum(item.surplusses), reverse=True)
        unique_solutions = {}
        for solution in solutions_sorted_by_surplus:
            if solution.source_id not in unique_solutions or sum(solution.surplusses) > sum(unique_solutions[solution.source_id].surplusses):
                unique_solutions[solution.source_id] = solution
        
        # Convert the dictionary back to a list
        unique_solutions = list(unique_solutions.values())
        
        per_source_id_solutions = {}
        for solution in solutions_sorted_by_surplus:
            if solution.source_id not in per_source_id_solutions:
                per_source_id_solutions[solution.source_id] = []
            per_source_id_solutions[solution.source_id].append(solution)
                
        # Optional: Sort solutions within each source_id by surplus
        for source_id in per_source_id_solutions:
           per_source_id_solutions[source_id].sort(key=lambda item: sum(item.surplusses), reverse=True)

        verbose=True
        clearing_prices = {}
        total_surplus = 0
        trades = []
        interactions = []
        
        for source_id, solutions in per_source_id_solutions.items():
            #best_solution = solutions[0]  # Use this insdead of the nex cycle for the valid clearing prices
            for best_solution in solutions:            
                clearing_prices[source_id] = best_solution.original_token_clearing_price
                total_surplus += sum(best_solution.surplusses)
                
                # Assuming seller_orderbooks contains the seller IDs
                for seller_orderbook, executedAmount in zip(best_solution.seller_orderbooks, best_solution.inputs_per_order):
                    trades.append({
                        "kind": "fulfillment",
                        "order": str(seller_orderbook.address),  # Adjust this if the ID is stored differently
                        "fee": "string",
                        "executedAmount": str(executedAmount)
                    })
                
                interactions.append(
                    construct_liquidity_interactions(best_solution.inputs_per_order, 
                                                     best_solution.adjusted_returns_per_order,
                                                     best_solution.target_id, source_id)
                )
                
                for executed_cycle in best_solution.executed_cycles:
                    amm_interactions = construct_custom_interactions(executed_cycle)
                    interactions.append(amm_interactions)
                    if len(best_solution.seller_orderbooks) > 1:
                        jit_order = construct_jit_order(source_id, source_id,
                                                        executed_cycle[0]['startAmount'],
                                                        executed_cycle[1][-1])
                        trades.append(jit_order)
            
                if verbose:
                    print('Source_id', source_id)
                    print('Target_id', best_solution.target_id)
                    print('Inputs WETH', best_solution.eth_inputs_per_order)
                    print('Returns WETH', best_solution.eth_returns_per_order)
                    print('Adjusted returns WETH', best_solution.adjusted_returns_per_order)
                    print('Sellers orderbook', best_solution.seller_orderbooks)
                    print('Surplus', total_surplus)
                    print('Original clearing price', best_solution.original_token_clearing_price)
                    print('Our clearing price', best_solution.our_token_clearing_price)
                    print('Original tokens rate', best_solution.original_tokens_rate)
                    print('Our tokens rate', best_solution.our_tokens_rate)
                    print('\n-------------------------------------------------------------------------\n')
        
        #for token_pair, rate in tokens_rate.items():
        resulted_solution["solutions"][0]["prices"]= clearing_prices
        
        resulted_solution["solutions"][0]["trades"] = trades
        resulted_solution["solutions"][0]["interactions"] = interactions

        return resulted_solution
