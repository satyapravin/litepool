import os
import json
from datetime import datetime
import requests
import numpy as np
from decimal import Decimal, getcontext
from dataclasses import dataclass
from typing import List, Dict, Tuple
import torch
from datatypes import SolveRequest
from preprocessing import ProcessedOrederbook, ProcessedAMM, SoulutionComponents, TokensRegistry
from postprocessing import construct_jit_order, construct_custom_interactions, construct_liquidity_interactions
from pathfinder import create_exchange_dict, compute_WETH_max_exchange_and_flow, find_paths, orderbook_filter_cycles, \
    create_transport_solution
from orderbook_utils import limit_sell_surplus, limit_buy_surplus, detect_rich_orderbook, get_indicies, \
    get_WETH_amounts, get_pool_WETH_amounts, simulate_cycle_outputs
from price_extractor import torch_find_arb

from pydantic import BaseModel, Field
getcontext().prec = 36


#import numpy as np
#from typing import List, Dict, Tuple

@dataclass
class SoulutionComponents:
    seller_orderbooks: List
    source_id: str
    target_id: str
    inputs_per_order: List
    eth_inputs_per_order: List
    eth_returns_per_order: List
    adjusted_returns_per_order: List
    trades: List
    interactions: List
    original_tokens_rate: float
    our_tokens_rate: List
    original_token_clearing_price: str
    clearing_prices: str
    sellETHprice: str
    buyETHprice: str
    surplusses: List
    totalGasUsed: str
    
def merge_dicts(list_of_dicts):
    return {k: v for d in list_of_dicts for k, v in d.items()}

def merge_lists(list_of_lists):
    return [item for sublist in list_of_lists for item in sublist]
    
def process_cycles_and_orders(valid_cycle_stat, solving_orderbook):
    single_cycle = valid_cycle_stat[0]
    single_cycle_amount = single_cycle['max_eth_flow']
    
    eth_inputs, sellers_ids, inputs, sellingETH = [], [], [], 0
    seller_orderbooks = []
    
    for order, _ in solving_orderbook[1]['orders']:
        if 1 / order.ETH_limit_price < single_cycle['final_rate']:
            #print('acceptable_rate', 1 / order.ETH_limit_price)
            #print(order)
            eth_inputs.append(order.sellETH)
            sellers_ids.append(order.address)
            inputs.append(int(order.sellReference))
            sellingETH += order.sellETH
            seller_orderbooks.append(order)
            
            if sellingETH >= single_cycle_amount:
                break
    
    if sellingETH <= single_cycle_amount:
        eth_returns = [single_cycle_amount]
        user_price = {0: single_cycle['final_rate']}
    else:
        eth_returns, user_price = [], {}
        buyingETH = 0
        for j, cycle in enumerate(valid_cycle_stat):
            eth_returns.append(cycle['max_eth_flow'])
            user_price[j] = cycle['final_rate']
            buyingETH += cycle['max_eth_flow']
            if buyingETH >= sellingETH:
                break
    
    return eth_inputs, eth_returns, sellers_ids, inputs, seller_orderbooks, user_price

# def simulate_cycle_orderbook_outputs(cycle, pools, startAsset, startAmount=100000, debug=False):    
    
#     steps = []
#     amountOutHops = []
#     simulation_data ={
#     "startAsset": startAsset,
#     "startAmount": startAmount,
#     "steps":[]}
    
#     cycle_pools = [pools[int(idx)] for idx in cycle]
#     amountIn = startAmount
#     for order in cycle_pools:
#         #print(amountOut)
#         amountOut = int(amountIn*order.limit_price)
#         amountOutHops.append(amountOut)
#         amountIn = amountOut
#         steps.append({"Liquidity":{"pool":order.address, "token_in":order.buytoken, "token_out":order.selltoken}})

#     simulation_data["steps"] = steps
#     #print(amountOutHops)
#     simulation_response = cycle
#     if debug:
#         print(simulation_data)

#     return simulation_data, amountOut, amountOutHops

def simulate_uniswap_outputs(cycle, pools, startAsset, startAmount=100000, debug=False):
    simularion_url = 'http://18.223.66.155:8020/compute-complex-path'
    simulation_header = {'Content-Type': 'application/json'}

    simulation_data ={
    "startAsset": startAsset,
    "startAmount": startAmount,
    "steps":[]}
    
    #cycle_pools = [pools[idx] for idx in cycle]
    cycle_pools = pools
    
    steps = []
    for pool in cycle_pools:
        steps.append({"uniswapV2":{"pool":pool.address, "token_in":pool.buytoken, "token_out":pool.selltoken}})
    
    simulation_data["steps"] = steps
    if debug:
        print(simulation_data)

    simulation_response = requests.post(url=simularion_url, headers=simulation_header, json=simulation_data)
    #print(simulation_response.status_code)
    return simulation_response, simulation_data


class Solver:
    def __init__(self):
        self.reference_price = {}
        self.reference_tokens = []
        self.tokens_registry = TokensRegistry()
        
        # with open("./data/orderbook_pools_20240906_052653.json", "r") as f:
        #     pools = json.loads(f.read())
        # self.all_pools = pools

    def simulate_cycle_orderbook_outputs_(self, cycle, pools, startAsset, clearing_prices, startAmount=100000, debug=False):    
        steps = []
        cycle_orders = []
        cycle_interactions = []
        amountOutHops = []
        simulation_data ={
                "startAsset": startAsset,
                "startAmount": startAmount,
                "steps":[]}

        
        cycle_pools = [pools[int(idx)] for idx in cycle]
        usedGas=0
        amountIn = startAmount
        for order in cycle_pools:
        #if len(cycle_pools)>1:
            if order.kind!='uniswapV2':
                sellETHprice = int(self.reference_price[order.selltoken][0])
                buyETHprice = int(self.reference_price[order.buytoken][0])
                original_tokens_rate = buyETHprice / sellETHprice
                print('THIS ORDER IS-------', order.kind)
                print('INSIDE THE CYCLES----- DEFAULT CLEARING PRICE FOR THE BUY TOKEN-----', buyETHprice)
                our_tokens_rate = order.limit_price
                our_token_clearing_price = int(buyETHprice / (our_tokens_rate / original_tokens_rate))
                print('INSIDE THE CYCLES----- UPDATED CLEARING PRICE FOR THE BUY TOKEN-----', our_token_clearing_price)
                #self.reference_price[order.buytoken][0] = our_token_clearing_price
                clearing_prices[order.buytoken] = our_token_clearing_price
                #our_token_clearing_price = int(sellETHprice*(our_tokens_rate/original_tokens_rate))
                #clearing_prices[order.selltoken] = our_token_clearing_price
                    
                amountOut = int(amountIn*(order.limit_price))
                amountOutHops.append(amountOut)
                cycle_interactions.append({
                        "kind_interaction": "liquidity",
                        "id": 0,  # Unique ID for each interaction
                        "inputToken": order.buytoken,
                        "outputToken": order.selltoken,
                        "inputAmount": str(amountIn),
                        "outputAmount": str(amountOut),
                        "internalize": True
                    })
    
                cycle_orders.append({
                    "address": order.address,
                    "inputToken": order.buytoken,
                    "outputToken": order.selltoken,
                    "inputAmount": str(amountIn),
                    "outputAmount": str(amountOut)
                })
        
                amountIn = amountOut
                steps.append({"Liquidity":{"pool":order.address, "token_in":order.buytoken, "token_out":order.selltoken}})
                
            elif order.kind=='uniswapV2':
                #try:
                simulation_response, simulation_data = simulate_uniswap_outputs(None, [order], order.buytoken, int(amountIn), True)

                simulation_json = simulation_response.json()
                amountOut = simulation_json['amountOut']
                amountOutHops = simulation_json['amountOutHops']
                totalGasUsed = simulation_json['totalGasUsed']
                usedGas+=int(totalGasUsed)
                cycle_interactions.append({
                        "kind_interaction": "custom",
                        "id": 0,  # Unique ID for each interaction
                        "inputToken": order.buytoken,
                        "outputToken": order.selltoken,
                        "inputAmount": str(amountIn),
                        "outputAmount": str(amountOut),
                        "internalize": False
                    })
    
                cycle_orders.append({
                    "address": order.address,
                    "inputToken": order.buytoken,
                    "outputToken": order.selltoken,
                    "inputAmount": str(amountIn),
                    "outputAmount": str(amountOut)
                })
                amountIn = int(amountOut)
                steps.append({"Liquidity":{"pool":order.address, "token_in":order.buytoken, "token_out":order.selltoken}})
                #except Exception as e:
                #    print(f"Error in simulate_uniswap_outputs: {e}")
                #    continue  # Skip this iteration a
                
    
        #simulation_data["steps"] = steps
        #print(amountOutHops)
        #simulation_response = cycle
        #if debug:
        #    print(simulation_data)
    
        return simulation_data, clearing_prices, cycle_interactions, amountOutHops, cycle_orders, usedGas

    def preprocess_data(self, orderbook: SolveRequest, verbose=True) -> Tuple[List, List, List, Dict, Dict]:

        # Fetch pool data
        pools_url = 'http://18.223.66.155:8020/extract-v2-pools'
        pools_headers = {'Content-Type': 'application/json'}
        # original code
        for token in orderbook.tokens:
            self.reference_price[token.address] = [int(token.price), float(token.price) / 10 ** (18)]
            if int(token.price) == 10 ** 18:
                self.reference_tokens.append(token.address)

        orders_dict = {order.uid: order for order in orderbook.orders}

        addresses = np.load('data/updated_pool_addresses.npy').tolist()

        # actual_orderbook_pools = filter_pools(self.all_pools, self.reference_price)
        # print('Total actual orderbook pools:', len(actual_orderbook_pools))
        # addresses = [pool['pool_addr'] for pool in actual_orderbook_pools]
        # np.save('./data/updated_pool_adresses.npy', np.array(addresses))
        
        response = requests.post(pools_url, headers=pools_headers, json=addresses[:])
        orderbook_pools = response.json()

        # Process orders
        processed_orders = []
        all_orders = []
        partiallyFillable = 0
        NoNpartiallyFillable = 0

        for order in orderbook.orders:
            realsellamount = np.float64(str(order.sellAmount))
            realbuyamount = np.float64(str(order.buyAmount))
            sellETHprice = int(self.reference_price[order.sellToken][0])
            buyETHprice = int(self.reference_price[order.buyToken][0])
            
            sellETHamount, buyETHamount = get_WETH_amounts(order, self.reference_tokens,
                                                           sellETHprice, buyETHprice,
                                                           realsellamount, realbuyamount)

            if order.partiallyFillable:
                partiallyFillable += 1
            else:
                NoNpartiallyFillable += 1

            limit_price = np.float64(realsellamount / realbuyamount)
            ETH_limit_price = np.float64(sellETHamount / buyETHamount)

            if order.kind == 'buy':
                surplus = limit_buy_surplus(realsellamount, sellETHprice, realbuyamount, buyETHprice, limit_price)
            elif order.kind == 'sell':
                surplus = limit_sell_surplus(realsellamount, sellETHprice, realbuyamount, buyETHprice, limit_price)

            if surplus == 0:
                selected_orderbook = ProcessedOrederbook(
                    order.uid,
                    order.sellToken,
                    order.buyToken,
                    order.kind,
                    order.partiallyFillable,
                    realsellamount,
                    realbuyamount,
                    sellETHamount,
                    buyETHamount,
                    limit_price,
                    ETH_limit_price,
                    surplus,
                    1
                )

                all_orders.append(selected_orderbook)

                if sellETHamount / buyETHamount >= 0.99:
                    processed_orders.append(selected_orderbook)

        # Process pools
        selected_pools = []
        for order in orderbook_pools:
            #print(order)
            realsellamount = int(order['r0'])
            realbuyamount = int(order['r1'])
            try:
                sellETHprice = int(self.reference_price[order['t0']][0])
                buyETHprice = int(self.reference_price[order['t1']][0])
    
                sellETHamount, buyETHamount = get_pool_WETH_amounts(order, self.reference_tokens,
                                                               sellETHprice, buyETHprice,
                                                               realsellamount, realbuyamount,
                                                               sellkey='t0', buykey='t1')
                limit_price = np.float64(realsellamount / realbuyamount)
                ETH_limit_price = np.float64(sellETHamount / buyETHamount)
    
                if sellETHamount > 0.1:
                    selected_pools.append(ProcessedAMM(
                        order['pool_addr'],
                        order['t0'],
                        order['t1'],
                        None,
                        True,
                        realsellamount,
                        realbuyamount,
                        sellETHamount,
                        buyETHamount,
                        limit_price,
                        ETH_limit_price,
                        None,
                        1
                    ))
            except:
                continue

        # Optimize selected pools
        cfmms_potential = {}
        optimized_selected_pools = []
        for j, cfmm_data in enumerate(selected_pools):
            ETHprices = [self.reference_price[cfmm_data.selltoken][0], self.reference_price[cfmm_data.buytoken][0]]
            reserves = torch.tensor([cfmm_data.sellETH, cfmm_data.buyETH])
            v = torch.nn.parameter.Parameter(torch.tensor([1, 1], dtype=torch.float64), requires_grad=True)
            v_optimizer = torch.optim.Adadelta([v], lr=0.01)
            best_loss = 0
            best_v = v

            for _ in range(5):
                v_optimizer.zero_grad()
                Delta, Lambda = torch_find_arb(v, reserves, 0.997)
                objective_loss = (Lambda - Delta).sum()
                loss = -objective_loss
                loss.backward()
                v_optimizer.step()
                if objective_loss.item() > best_loss:
                    best_loss = objective_loss.item()
                    best_v = v
            try:
                Delta, Lambda = torch_find_arb(best_v, reserves, cfmm_data.fee)
                Delta, Lambda = Lambda.detach().numpy() - Delta.detach().numpy()
                token_changes = {}
                for i, x in enumerate([Delta, Lambda]):
                    if x < 0:
                        token_changes['input_index'] = i
                        token_changes['value_in'] = x
                        token_changes['token_in'] = [cfmm_data.selltoken, cfmm_data.buytoken][i]
                        token_changes['reserves_x'] = abs((token_changes['value_in'] / ETHprices[i]) * (10 ** (18 * 2)))
                    elif x > 0:
                        token_changes['value_out'] = x
                        token_changes['token_out'] = [cfmm_data.selltoken, cfmm_data.buytoken][i]
                        token_changes['reserves_y'] = abs((token_changes['value_out'] / ETHprices[i]) * (10 ** (18 * 2)))
                token_changes['surplus'] = objective_loss.item()
                cfmms_potential[j] = token_changes
    
                optimized_selected_pools.append(ProcessedAMM(
                    cfmm_data.address,
                    token_changes['token_out'],
                    token_changes['token_in'],
                    'uniswapV2',
                    True,
                    int(token_changes['reserves_y']),
                    int(token_changes['reserves_x']),
                    abs(token_changes['value_out']),
                    abs(token_changes['value_in']),
                    None,
                    abs(token_changes['value_out']) / abs(token_changes['value_in']),
                    None,
                    0.997,
                ))
            except:
                continue
        
        if verbose:
            print('PartiallyFillable:', partiallyFillable)
            print('NoNpartiallyFillable:', NoNpartiallyFillable)
            print('Selected orders:', len(all_orders))
            print('Top selected orders:', len(processed_orders))
            print('Selected pools:', len(selected_pools))
            print('Optimized selected pools:', len(optimized_selected_pools))
            print('\n-------------------------------------------------------------------------\n')

        return all_orders, processed_orders, optimized_selected_pools, orders_dict, cfmms_potential

        
    def solve(self, request: SolveRequest, verbose=True):
        resulted_solution = {
            "solutions": [
                {
                    "id": 0,
                    "prices": {},
                    "trades": [],
                    "pre_interactions": [],
                    "interactions": [],
                    "post_interactions": [],
                    "scores": [],
                    "gas": ""
                }
            ]
        }

        all_orders, processed_orders, optimized_selected_pools, orders_dict, cfmms_potential = self.preprocess_data(request)
        
        sorted_by_WETH = sorted(all_orders, key=lambda item: item.ETH_limit_price, reverse=True)
        pair_to_indices, _ = get_indicies(sorted_by_WETH, pair_key=True)

        unique_pairs = sorted_by_WETH[:500].copy()
        unique_pairs.extend(optimized_selected_pools)
        remaining_amounts = {idx: order.buyETH for idx, order in enumerate(unique_pairs)}
        prev_remaining_amounts = remaining_amounts.copy()
        
        swaps_to_drop = []
        used_tokens = []
        temporal_solutions = []
        tokens_rate = {}
        
        for i in range(len(pair_to_indices)):
            
            solving_orderbook = list(pair_to_indices.items())[i]
            source_id = solving_orderbook[0][0]
            target_id = solving_orderbook[0][1]
            sellETHprice = (self.reference_price[source_id][0])
            buyETHprice = (self.reference_price[target_id][0])

            jit_orderbook = []
            target_id_orders = 0
            for order in unique_pairs:
                if order.kind!='uniswapV2':
                    if order.selltoken!=source_id and order.selltoken!=target_id: #only a single order should have selltoken being equal to the target_id
                        if str(order.buytoken) == str(source_id):
                            #do not forget to include the surplus here
                            sellETHprice_ = (self.reference_price[order.selltoken][0])
                            buyETHprice_ = (self.reference_price[order.buytoken][0])
                            default_limit_rate = order.limit_price
                            clearing_limit_rate = np.float64(buyETHprice_/sellETHprice_)
    
                            if default_limit_rate>clearing_limit_rate: #clear by clearing price only the oreders that better than market
        
                                multiplyer = np.float64(clearing_limit_rate*order.buyReference)/np.float64(order.sellReference)
                                realsellamount = order.sellReference*multiplyer
                                if order.selltoken in self.reference_tokens:
                                    sellETHamount = order.sellReference/sellETHprice_
                                else:
                                    sellETHamount = order.sellReference*(sellETHprice_/10**(18*2))
                                ETH_limit_price = np.float64(sellETHamount/ order.buyETH)
        
        
                                updated_order = ProcessedOrederbook(
                                    order.address,
                                    order.selltoken,
                                    order.buytoken,
                                    order.kind+'Updated',
                                    order.partiallyFillable,
                                    realsellamount,
                                    order.buyReference,
                                    sellETHamount,
                                    order.buyETH,
                                    clearing_limit_rate,#order.sellReference/order.buyReference,
                                    ETH_limit_price,
                                    order.surplus,
                                    1)
                                
                                jit_orderbook.append(updated_order)
                                #print(order)
                                #print(updated_order)
                        else:
                            jit_orderbook.append(order)
                    
            for order in unique_pairs:
                if order.kind!='uniswapV2':
                    if order.selltoken==target_id: #only a single order should have selltoken being equal to the target_id
                        if str(order.buytoken) == str(source_id):
                            #do not forget to include the surplus here
                            sellETHprice_ = (self.reference_price[order.selltoken][0])
                            buyETHprice_ = (self.reference_price[order.buytoken][0])
                            default_limit_rate = order.limit_price
                            clearing_limit_rate = np.float64(buyETHprice_/sellETHprice_)
    
                            if default_limit_rate>clearing_limit_rate: #clear by clearing price only the oreders that better than market
        
                                multiplyer = np.float64(clearing_limit_rate*order.buyReference)/np.float64(order.sellReference)
                                realsellamount = order.sellReference*multiplyer
                                if order.selltoken in self.reference_tokens:
                                    sellETHamount = order.sellReference/sellETHprice_
                                else:
                                    sellETHamount = order.sellReference*(sellETHprice_/10**(18*2))
                                ETH_limit_price = np.float64(sellETHamount/ order.buyETH)
        
        
                                updated_order = ProcessedOrederbook(
                                    order.address,
                                    order.selltoken,
                                    order.buytoken,
                                    order.kind+'Updated',
                                    order.partiallyFillable,
                                    realsellamount,
                                    order.buyReference,
                                    sellETHamount,
                                    order.buyETH,
                                    clearing_limit_rate,#order.sellReference/order.buyReference,
                                    ETH_limit_price,
                                    order.surplus,
                                    1)
                                
                                jit_orderbook.append(updated_order)
                                #print(order)
                                #print(updated_order)
                        else:
                            jit_orderbook.append(order)
                        #jit_orderbook.append(order)
                        break
            for order in unique_pairs:
                if order.kind=='uniswapV2':
                    jit_orderbook.append(order)

            #print(len(unique_pairs))
            #print(len(jit_orderbook))
                    
            original_tokens_rate = buyETHprice / sellETHprice
            exchange_dict = create_exchange_dict(jit_orderbook.copy(), swaps_to_drop)
            
            cycles = []
            trades = []
            solution_amountsIn = []
            solution_amountsOut = []
            our_tokens_rate = []
            executed_cycles = []
            adjusted_tokens_rate = []
            surpluses = []
            interactions = []
            clearing_prices = {}
            totalGasUsed = 0
            
            for path_length in range(4):
                find_paths(exchange_dict, source_id, target_id, [], cycles, path_length)
        
            _, _, valid_cycle_stat, _, remaining_amounts = orderbook_filter_cycles(cycles, jit_orderbook, compute_WETH_max_exchange_and_flow, prev_remaining_amounts, 0.99, True)

            if len(valid_cycle_stat) == 0:
                continue

            eth_amountsIn, eth_amountsGet, _, _, seller_orderbooks, user_price = process_cycles_and_orders(valid_cycle_stat, solving_orderbook)

            if len(eth_amountsIn) == 0 or len(eth_amountsGet) == 0:
                continue

            #if len(eth_amountsIn) != 1 or len(eth_amountsGet) != 1:
            #    continue
                
            transport_solution = create_transport_solution(eth_amountsIn, eth_amountsGet, user_price)

            if transport_solution.sum() <= 0:
                continue

            #print(source_id)
            #print(target_id)
            #print('how much buyers we have', eth_amountsIn)
            #print('how much sellers we have', eth_amountsGet)
            #print(valid_cycle_stat)
            all_orders = {}  # Dictionary to track all orders and their executed amounts
            for c, (order, eth_cycle_amountsIn) in enumerate(zip(seller_orderbooks, transport_solution)):
                
                cycle_amountsIn =[]
                cycle_amountsOut =[]
                for eth_amountIn in eth_cycle_amountsIn:
                    if eth_amountIn != 0.0:
                        
                        amountIn = int((eth_amountIn / sellETHprice) * (10 ** (18 * 2)))
                        simulation_data, clearing_prices, cycle_interactions, amountOutHops, cycle_orders, usedGas = self.simulate_cycle_orderbook_outputs_(valid_cycle_stat[c]['cycle'], 
                                                                                                                                          jit_orderbook, 
                                                                                                                                          source_id, 
                                                                                                                                          clearing_prices, 
                                                                                                                                          amountIn, 
                                                                                                                                          False)
                        totalGasUsed+=usedGas
                        amountOut = amountOutHops[-1]

                        seller_interaction = {
                            "kind_interaction": "liquidity",
                            "id": 0,  # Unique ID for each interaction
                            "inputToken": order.buytoken,
                            "outputToken": order.selltoken,
                            "inputAmount": str(amountOut),
                            "outputAmount": str(amountIn),
                            "internalize": True
                        }

                        for c_int in cycle_interactions:
                            interactions.append(c_int)
                        interactions.append(seller_interaction)
                        cycle_amountsIn.append(np.float64(amountIn))
                        cycle_amountsOut.append(np.float64(amountOut))

                        # Update all_orders with cycle orders
                        for cycle_order in cycle_orders:
                            if cycle_order['address'] not in all_orders:
                                all_orders[cycle_order['address']] = 0
                            all_orders[cycle_order['address']] += int(cycle_order['outputAmount'])
                        
                        #executed_cycles.append([simulation_data, amountOutHops])
                
                solution_amountsIn.append(cycle_amountsIn)
                solution_amountsOut.append(cycle_amountsOut)

            amountsIn = np.sum(np.array(solution_amountsIn), axis=0)
            amountsOut = np.sum(np.array(solution_amountsOut), axis=0)
            print('amountsIn',amountsIn)
            print('amountsOut',amountsOut)

            for order, executedAmount in zip(seller_orderbooks, amountsIn):
                if order.address not in all_orders:
                    all_orders[order.address] = 0
                all_orders[order.address] += int(executedAmount)
                
            trades = []
            for order_address, executed_amount in all_orders.items():
                trades.append({
                    "kind": "fulfillment",
                    "order": str(order_address),
                    "fee": " ",
                    "executedAmount": str(executed_amount)
                })
            # here we need to add jit interactions

            print('trades',trades)
            print('interactions', interactions)

            #print('amountsIn',amountsIn)
            #print('amountsOut',amountsOut)
            for amountIn, amountOut in zip(amountsIn, amountsOut):
                our_tokens_rate.append(int(amountIn) / int(amountOut))

            # using sell ETH price from the updated prices
            #print(len(clearing_prices))
            #if len(clearing_prices)>1:
            #    sellETHprice = clearing_prices[source_id]
            
            original_tokens_rate = buyETHprice / sellETHprice
            #sellETHprice = (self.reference_price[source_id][0])
            #buyETHprice = (self.reference_price[target_id][0])
            #print('our_tokens_rate', our_tokens_rate)
            #original_tokens_rate = buyETHprice / sellETHprice
            if len(our_tokens_rate)==0:
                continue
            our_tokens_rate = round(max(our_tokens_rate), 18) #36 #or min here

            
            adjusted_amountsOut = [int((int(amountIn) / our_tokens_rate)) for amountIn in amountsIn]
            eth_amountsOut = [x * (buyETHprice / 10 ** (18 * 2)) for x in adjusted_amountsOut]

            #our_token_clearing_price = int(sellETHprice*(our_tokens_rate/original_tokens_rate))
            our_token_clearing_price = int(buyETHprice / (our_tokens_rate / original_tokens_rate))

            #clearing_prices[source_id] = our_token_clearing_price 
            clearing_prices[target_id] = our_token_clearing_price
            #print('our_token_clearing_price', clearing_prices)
            print('--------------/n')
            #make the validation that amounutsOut is not bigger that the limit price
            
            for order, amountIn, amountOut in zip(seller_orderbooks, amountsIn, adjusted_amountsOut):
                if order.kind == 'sell':
                    surplus = limit_sell_surplus(int(amountIn), int(sellETHprice), int(amountOut),
                                                 int(buyETHprice), np.float64(order.limit_price))
                else:
                    surplus = limit_buy_surplus(int(amountIn), int(sellETHprice), int(amountOut),
                                                int(buyETHprice), np.float64(order.limit_price))
                    
                surpluses.append(int(surplus) / (10 ** (18 * 2)))
                adjusted_tokens_rate.append(int(amountIn) / int(amountOut)) # we changed buy amounts. P.s adjusted_tokens_rate must be equal to our_tokens_rate

            print('adjusted_tokens_rate', adjusted_tokens_rate)
            print('amountsOut',amountsOut)
            print('adjusted_amountsOut', adjusted_amountsOut)

            if sum(surpluses)>0:
                temporal_solutions.append(SoulutionComponents(seller_orderbooks = seller_orderbooks,
                                            source_id = str(source_id),
                                            target_id = str(target_id),
                                            inputs_per_order = amountsIn,
                                            eth_inputs_per_order =  eth_amountsIn,
                                            eth_returns_per_order = eth_amountsOut,
                                            adjusted_returns_per_order= adjusted_amountsOut,
                                            trades = trades,
                                            interactions= interactions,
                                            original_tokens_rate = original_tokens_rate,
                                            our_tokens_rate = adjusted_tokens_rate,
                                            original_token_clearing_price = buyETHprice,
                                            clearing_prices = clearing_prices,
                                            sellETHprice = sellETHprice,
                                            buyETHprice = buyETHprice, 
                                            surplusses= surpluses,
                                            totalGasUsed=totalGasUsed))
                        
                prev_remaining_amounts = remaining_amounts
                    
            #except:
                #continue
        
        solutions_sorted_by_surplus = sorted(temporal_solutions, key=lambda item: sum(item.surplusses), reverse=True)
        # unique_solutions = {}
        # for solution in solutions_sorted_by_surplus:
        #     if solution.source_id not in unique_solutions or sum(solution.surplusses) > sum(unique_solutions[solution.source_id].surplusses):
        #         unique_solutions[solution.source_id] = solution
        
        # # Convert the dictionary back to a list
        # unique_solutions = list(unique_solutions.values())
        
        per_source_id_solutions = {}
        for solution in solutions_sorted_by_surplus:
            if solution.source_id not in per_source_id_solutions:
                per_source_id_solutions[solution.source_id] = []
            per_source_id_solutions[solution.source_id].append(solution)
                
        # Optional: Sort solutions within each source_id by surplus
        for source_id in per_source_id_solutions:
           per_source_id_solutions[source_id].sort(key=lambda item: sum(item.surplusses), reverse=True)


        per_target_id_solutions = {}
        for solution in solutions_sorted_by_surplus:
            if solution.target_id not in per_target_id_solutions:
                per_target_id_solutions[solution.target_id] = []
            per_target_id_solutions[solution.target_id].append(solution)
                
        # Optional: Sort solutions within each source_id by surplus
        for target_id in per_target_id_solutions:
           per_target_id_solutions[target_id].sort(key=lambda item: sum(item.surplusses), reverse=True)

        print('len(per_source_id_solutions)', len(per_source_id_solutions))
        print('len(per_target_id_solutions)', len(per_target_id_solutions))

        verbose=True
        total_clearing_prices = []
        total_surplus = 0
        trades = []
        interactions = []
        totalGasUsed = 0

        #insdead of trades crate an common class that contain both trades and interactions
        #for source_id, solutions in per_source_id_solutions.items():
        for target_id, solutions in per_target_id_solutions.items():
            #best_solution = solutions[0]  # Use this insdead of the next cycle for the valid clearing prices
            for best_solution in solutions:            
                #clearing_prices[source_id] = best_solution.original_token_clearing_price
                total_surplus += sum(best_solution.surplusses)

                trades.append(best_solution.trades)
                interactions.append(best_solution.interactions)
                totalGasUsed+=best_solution.totalGasUsed
                total_clearing_prices.append(best_solution.clearing_prices)
                # # Assuming seller_orderbooks contains the seller IDs
                # for seller_orderbook, executedAmount in zip(best_solution.seller_orderbooks, best_solution.inputs_per_order): #insert here orders as well
                #     trades.append({
                #         "kind": "fulfillment",
                #         "order": str(seller_orderbook.address),  # Adjust this if the ID is stored differently
                #         "fee": "string",
                #         "executedAmount": str(executedAmount)
                #     })
                
                # interactions.append(
                #     construct_liquidity_interactions(best_solution.inputs_per_order, 
                #                                      best_solution.adjusted_returns_per_order,
                #                                      best_solution.target_id, 
                #                                      source_id)
                # )
                
                # for executed_cycle in best_solution.executed_cycles:
                #     interactions.append(construct_liquidity_interactions(executed_cycle.inputs_per_order, 
                #                                      executed_cycle.returns_per_order,
                #                                      executed_cycle.target_id, 
                #                                      executed_cycle.source_id))
                    # amm_interactions = construct_custom_interactions(executed_cycle)
                    # interactions.append(amm_interactions)
                    # if len(best_solution.seller_orderbooks) > 1:
                    #     jit_order = construct_jit_order(source_id, source_id,
                    #                                     executed_cycle[0]['startAmount'],
                    #                                     executed_cycle[1][-1])
                    #     trades.append(jit_order)
            
                if verbose:
                    print('\n--------------------------Report-----------------------------------------')
                    print('Sell token', best_solution.source_id, best_solution.sellETHprice)
                    print('Buy token', best_solution.target_id, best_solution.buyETHprice)
                    print('Inputs WETH', best_solution.eth_inputs_per_order)
                    print('Returns WETH', best_solution.eth_returns_per_order)
                    print('Adjusted returns WETH', best_solution.adjusted_returns_per_order)
                    print('totalGasUsed', best_solution.totalGasUsed)
                    print('Surplus', sum(best_solution.surplusses))
                    print('Original clearing price',best_solution.target_id, best_solution.original_token_clearing_price)
                    print('Our clearing prices', best_solution.clearing_prices)
                    print('Original tokens rate', best_solution.original_tokens_rate)
                    print('Our tokens rate', best_solution.our_tokens_rate)
                    print('-------------------------------------------------------------------------\n')
        
        #for token_pair, rate in tokens_rate.items():
        resulted_solution["solutions"][0]["prices"] = merge_dicts(total_clearing_prices)
        resulted_solution["solutions"][0]["trades"] = merge_lists(trades)
        resulted_solution["solutions"][0]["interactions"] = merge_lists(interactions)
        resulted_solution["solutions"][0]["score"] = str(total_surplus) #need to change it into the real WETH price
        resulted_solution["solutions"][0]["gas"] = str(totalGasUsed)

        return resulted_solution
